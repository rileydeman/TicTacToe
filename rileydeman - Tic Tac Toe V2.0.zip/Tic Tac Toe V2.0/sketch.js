//Variables

let textColour = "#FFFFFF";
let backgroundColour = "#121212";
let copyright = "© rileydeman™";

///Rect Information
let xPos = 50; //Start x Position
let yPos = 50; //Start y Position
let rectWidth = 250; //Width of Grid Rectangles
let rectHeigth = 250; //Height of Grid Rectangles
let rectBorderRadius = 25; //Border radius of Grid Rectangles
let borderColour;

let rect1Clicked = false;
let rect2Clicked = false;
let rect3Clicked = false;
let rect4Clicked = false;
let rect5Clicked = false;
let rect6Clicked = false;
let rect7Clicked = false;
let rect8Clicked = false;
let rect9Clicked = false;

let rect10Clicked = false;
let rect11Clicked = false;
let rect12Clicked = false;
let rect13Clicked = false;
let rect14Clicked = false;
let rect15Clicked = false;
let rect16Clicked = false;


let rectColour;

let rect1Owner;
let rect2Owner;
let rect3Owner;
let rect4Owner;
let rect5Owner;
let rect6Owner;
let rect7Owner;
let rect8Owner;
let rect9Owner;

let rect10Owner;
let rect11Owner;
let rect12Owner;
let rect13Owner;
let rect14Owner;
let rect15Owner;
let rect16Owner;

///Player Information
let currentPlayer = "Player 1";
let p1Colour = "#8000FF";
let p2Colour = "#FF0000";
let p1Wins = 0;
let p2Wins = 0;

//Game Information
let inProgress = true;
let GameVersion = "V2.0";
let setWin = false;
let lastWin = "Player 1";
let gameGrid = "3x3";
let theme = "default";

//Endscreen Information
let endScreenHeigth = 900;
let endScreenWidth = 900;

//Button Information
let buttonxPos = endScreenWidth + 10;
let buttonyPos = endScreenHeigth/3 + 50;
let buttonWidth = 125;
let buttonHeight = 62.5;
let buttonClickedColour = "#8000FF";
let buttonUnclickedColour = "#3B3B3B";
let buttonHoverColourGrid = "#C285FF";
let buttonHoverColourTheme = "#C285FF";
let buttonTextColour = "#FFFFFF";

function setup() {
  createCanvas(1500, 900);
  frameRate(165);

  currentPlayer = random(['Player 1', 'Player 2']);
}

function draw() {
  background(backgroundColour); //Background Colour

  //Theme Setup
  if(theme == "light") {
    backgroundColour = "#FFFFFF";
    textColour = "#000000";
    borderColour = "#FFFFFF";
    rectColour = "#858282";

    buttonUnclickedColour = "#8A8888";
  }
  else if (theme == "default") {
    backgroundColour = "#121212";
    textColour = "#FFFFFF";
    borderColour = "#121212"
    rectColour = "#FFFFFF";

    buttonUnclickedColour = "#3B3B3B";
  }


  //Game Options
  textFont("TradeWinds");
  fill(textColour);
  textSize(35);
  text("Game options:", buttonxPos, buttonyPos - 80);

  ///Game Options Buttons
  if (gameGrid == "3x3") {
    fill(buttonClickedColour);
    rect(buttonxPos, buttonyPos, buttonWidth, buttonHeight, 20, 0, 0, 20);

    if(mouseX > buttonxPos + buttonWidth && mouseX < buttonxPos + 2*buttonWidth && mouseY > buttonyPos && mouseY < buttonyPos + buttonHeight) {
      fill(buttonHoverColourGrid)
    }else{
      fill(buttonUnclickedColour);
    }
    rect(buttonxPos + buttonWidth, buttonyPos, buttonWidth, buttonHeight, 0, 20, 20, 0);

    fill(textColour);
    textSize(20);
    text("Grid mode:", buttonxPos + 10, buttonyPos - 20);

    fill(buttonTextColour);
    textSize(40);
    text("3x3", buttonxPos + (buttonWidth/3) - 12.5, buttonyPos + (buttonHeight/2) + 12.5);
    text("4x4", buttonxPos + (buttonWidth/3) - 20 + buttonWidth, buttonyPos + (buttonHeight/2) + 12.5);

  }else if (gameGrid == "4x4") {
    
    if(mouseX > buttonxPos && mouseX < buttonxPos + buttonWidth && mouseY > buttonyPos && mouseY < buttonyPos + buttonHeight) {
      fill(buttonHoverColourGrid)
    }else{
      fill(buttonUnclickedColour);
    }
    rect(buttonxPos, buttonyPos, buttonWidth, buttonHeight, 20, 0, 0, 20);

    fill(buttonClickedColour);
    rect(buttonxPos + buttonWidth, buttonyPos, buttonWidth, buttonHeight, 0, 20, 20, 0);

    fill(textColour);
    textSize(20);
    text("Grid mode:", buttonxPos + 10, buttonyPos - 20);

    fill(buttonTextColour);
    textSize(40);
    text("3x3", buttonxPos + (buttonWidth/3) - 12.5, buttonyPos + (buttonHeight/2) + 12.5);
    text("4x4", buttonxPos + (buttonWidth/3) - 20 + buttonWidth, buttonyPos + (buttonHeight/2) + 12.5);
  }

  if (theme == "default") {
    fill(buttonClickedColour);
    rect(buttonxPos, buttonyPos + buttonHeight + 65, buttonWidth, buttonHeight, 20, 0, 0, 20);

    if(mouseX > buttonxPos + buttonWidth && mouseX < buttonxPos + 2*buttonWidth && mouseY > buttonyPos + buttonHeight + 65 && mouseY < buttonyPos + 65 + (2*buttonHeight)) {
      fill(buttonHoverColourTheme)
    }else{
      fill(buttonUnclickedColour);
    }
    rect(buttonxPos + buttonWidth, buttonyPos + buttonHeight + 65, buttonWidth, buttonHeight, 0, 20, 20, 0);

    fill(textColour);
    textSize(20);
    text("Theme:", buttonxPos + 10, buttonyPos + buttonHeight + 45);

    fill(buttonTextColour);
    textSize(22.5);
    text("Defeault", buttonxPos + (buttonWidth/4) - 17.5, buttonyPos + (2.5*buttonHeight) + 7.5);
    text("Light", buttonxPos + (buttonWidth/3) + buttonWidth - 10, buttonyPos + (2.5*buttonHeight) + 7.5);

  }else if (theme == "light") {
    
    if(mouseX > buttonxPos && mouseX < buttonxPos + buttonWidth && mouseY > buttonyPos + buttonHeight + 65 && mouseY < buttonyPos + 65 + (2*buttonHeight)) {
      fill(buttonHoverColourTheme);
    }else{
      fill(buttonUnclickedColour);
    }
    rect(buttonxPos, buttonyPos + buttonHeight + 65, buttonWidth, buttonHeight, 20, 0, 0, 20);

    fill(buttonClickedColour);
    rect(buttonxPos + buttonWidth, buttonyPos + buttonHeight + 65, buttonWidth, buttonHeight, 0, 20, 20, 0);

    fill(textColour);
    textSize(20);
    text("Theme:", buttonxPos + 10, buttonyPos + buttonHeight + 45);

    fill(buttonTextColour);
    textSize(22.5);
    text("Defeault", buttonxPos + (buttonWidth/4) - 17.5, buttonyPos + (2.5*buttonHeight) + 7.5);
    text("Light", buttonxPos + (buttonWidth/3) + buttonWidth - 10, buttonyPos + (2.5*buttonHeight) + 7.5);
  }
  
  //Current Player text
  if (currentPlayer == "Player 1") {
    fill(p1Colour);
  }else if (currentPlayer == "Player 2") {
    fill(p2Colour);
  }

  if (gameGrid == "3x3") {
  rect(xPos, yPos + 3*rectHeigth + 10, 40, 40);

  textFont("Helvitica");
  fill(textColour);
  textSize(15);
  text(copyright, xPos + 2*rectWidth + 140, yPos + 3*rectHeigth + 43);

  textFont("TradeWinds");
  textSize(25);
  text(currentPlayer, xPos + 45, yPos + 3*rectHeigth + 40);
  text(GameVersion, 10, 30);
  } else if (gameGrid == "4x4") {
    rect(xPos, yPos + 4*rectHeigth + 10, 40, 40);
  
    textFont("Helvitica");
    fill(textColour);
    textSize(15);
    text(copyright, xPos + 3*rectWidth + 77.5, yPos + 4*rectHeigth + 43);
  
    textFont("TradeWinds");
    textSize(25);
    text(currentPlayer, xPos + 45, yPos + 4*rectHeigth + 40);
    text(GameVersion, 10, 30);
    }

  //Rect theme
  stroke(borderColour)
  strokeWeight(12); //Stroke Width
  
  //Grid
  if (gameGrid == "3x3") {
   //First Line
    if (rect1Clicked == true){
      if (rect1Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect1Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
   rect(xPos, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 1

  if (rect2Clicked == true){
    if (rect2Owner == "Player 1") {
      fill(p1Colour);
    }else if (rect2Owner == "Player 2") {
      fill(p2Colour);
    }
  }else{
    fill(rectColour);
  }
   rect(xPos + rectWidth, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 2

   if (rect3Clicked == true){
    if (rect3Owner == "Player 1") {
      fill(p1Colour);
    }else if (rect3Owner == "Player 2") {
      fill(p2Colour);
    }
  }else{
    fill(rectColour);
  }
   rect(xPos + 2*rectWidth, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 3
    
   //Second Line
   if (rect4Clicked == true){
    if (rect4Owner == "Player 1") {
      fill(p1Colour);
    }else if (rect4Owner == "Player 2") {
      fill(p2Colour);
    }
  }else{
    fill(rectColour);
  }
   rect(xPos, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 4

   if (rect5Clicked == true){
    if (rect5Owner == "Player 1") {
      fill(p1Colour);
    }else if (rect5Owner == "Player 2") {
      fill(p2Colour);
    }
  }else{
    fill(rectColour);
  }
   rect(xPos + rectWidth, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 5

   if (rect6Clicked == true){
    if (rect6Owner == "Player 1") {
      fill(p1Colour);
    }else if (rect6Owner == "Player 2") {
      fill(p2Colour);
    }
  }else{
    fill(rectColour);
  }
   rect(xPos + 2*rectWidth, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 6
    
   //Third Line
   if (rect7Clicked == true){
    if (rect7Owner == "Player 1") {
      fill(p1Colour);
    }else if (rect7Owner == "Player 2") {
      fill(p2Colour);
    }
  }else{
    fill(rectColour);
  }
   rect(xPos, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 7

   if (rect8Clicked == true){
    if (rect8Owner == "Player 1") {
      fill(p1Colour);
    }else if (rect8Owner == "Player 2") {
      fill(p2Colour);
    }
  }else{
    fill(rectColour);
  }
   rect(xPos + rectWidth, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 8

   if (rect9Clicked == true){
    if (rect9Owner == "Player 1") {
      fill(p1Colour);
    }else if (rect9Owner == "Player 2") {
      fill(p2Colour);
    }
  }else{
    fill(rectColour);
  }
   rect(xPos + 2*rectWidth, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 9
  }
  else if (gameGrid == "4x4") {
    //First Line
    if (rect1Clicked == true){
      if (rect1Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect1Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 1
     
    if (rect2Clicked == true){
      if (rect2Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect2Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + rectWidth, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 2
     
    if (rect3Clicked == true){
      if (rect3Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect3Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + 2*rectWidth, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 3

    if (rect4Clicked == true){
      if (rect4Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect4Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + 3*rectWidth, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 4
     
    //Second Line
    if (rect5Clicked == true){
      if (rect5Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect5Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 5
     
    if (rect6Clicked == true){
      if (rect6Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect6Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + rectWidth, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 6
     
    if (rect7Clicked == true){
      if (rect7Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect7Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + 2*rectWidth, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 7

    if (rect8Clicked == true){
      if (rect8Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect8Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + 3*rectWidth, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 8
     
    //Third Line
    if (rect9Clicked == true){
      if (rect9Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect9Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 9
     
    if (rect10Clicked == true){
      if (rect10Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect10Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + rectWidth, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 10
     
    if (rect11Clicked == true){
      if (rect11Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect11Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + 2*rectWidth, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 11

    if (rect12Clicked == true){
      if (rect12Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect12Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + 3*rectWidth, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 12

    //Fourth Line
    if (rect13Clicked == true){
      if (rect13Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect13Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos, yPos + 3*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 13
     
    if (rect14Clicked == true){
      if (rect14Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect14Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + rectWidth, yPos + 3*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 14
     
    if (rect15Clicked == true){
      if (rect15Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect15Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + 2*rectWidth, yPos + 3*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 15

    if (rect16Clicked == true){
      if (rect16Owner == "Player 1") {
        fill(p1Colour);
      }else if (rect16Owner == "Player 2") {
        fill(p2Colour);
      }
    }else{
      fill(rectColour);
    }
    rect(xPos + 3*rectWidth, yPos + 3*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 16
   }

  //Leaderboard

  textFont("TradeWinds");
  strokeWeight(0)

  if(p1Wins > p2Wins) {
    fill(textColour);
    textSize(45);
    text("Leaderboard:", endScreenWidth + 10, yPos + 40);

    textSize(25);
    text("Player 1 (" + p1Wins + ")", endScreenWidth + 60, yPos + 90);
    text("Player 2 (" + p2Wins + ")", endScreenWidth + 60, yPos + 140);

    stroke("#FFFFFF");
    strokeWeight(1);

    fill(p1Colour);
    rect(endScreenWidth + 10, yPos + 60, 40, 40);

    fill(p2Colour);
    rect(endScreenWidth + 10, yPos + 110, 40, 40);
  }else if(p1Wins < p2Wins) {
    fill(textColour);
    textSize(45);
    text("Leaderboard:", endScreenWidth + 10, yPos + 40);

    textSize(25);
    text("Player 2 (" + p2Wins + ")", endScreenWidth + 60, yPos + 90);
    text("Player 1 (" + p1Wins + ")", endScreenWidth + 60, yPos + 140);

    stroke("#FFFFFF");
    strokeWeight(1);

    fill(p2Colour);
    rect(endScreenWidth + 10, yPos + 60, 40, 40);

    fill(p1Colour);
    rect(endScreenWidth + 10, yPos + 110, 40, 40);
  }else{
    fill(textColour);
    textSize(45);
    text("Leaderboard:", endScreenWidth + 10, yPos + 40);

    textSize(25);
    text("Player 1 (" + p1Wins + ")", endScreenWidth + 60, yPos + 90);
    text("Player 2 (" + p2Wins + ")", endScreenWidth + 60, yPos + 140);

    stroke("#FFFFFF");
    strokeWeight(1);

    fill(p1Colour);
    rect(endScreenWidth + 10, yPos + 60, 40, 40);

    fill(p2Colour);
    rect(endScreenWidth + 10, yPos + 110, 40, 40);
  }

  //3 or 4 in a row checks

  strokeWeight(0);

  if(gameGrid == "3x3") {
    //Draw
    if(rect1Clicked == true && rect2Clicked == true && rect3Clicked == true && rect4Clicked == true && rect5Clicked == true &&
      rect6Clicked == true && rect7Clicked == true && rect8Clicked == true && rect9Clicked == true) {
      fill(backgroundColour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Draw/No Winner!", (width-600)/4, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
    }

    //Horizontal Line 1
    if(rect1Clicked == true && rect2Clicked == true && rect3Clicked == true) {
      if(rect1Owner == "Player 1" && rect2Owner == "Player 1" && rect3Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect1Owner == "Player 2" && rect2Owner == "Player 2" && rect3Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Horizontal Line 2
    if(rect4Clicked == true && rect5Clicked == true && rect6Clicked == true) {
      if(rect4Owner == "Player 1" && rect5Owner == "Player 1" && rect6Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect4Owner == "Player 2" && rect5Owner == "Player 2" && rect6Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p1Wins + " wins");
          setWin = true;
        }
      }
    }

    //Horizontal Line 3
    if(rect7Clicked == true && rect8Clicked == true && rect9Clicked == true) {
      if(rect7Owner == "Player 1" && rect8Owner == "Player 1" && rect9Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect7Owner == "Player 2" && rect8Owner == "Player 2" && rect9Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";
        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p1Wins + " wins");
          setWin = true;
        }
      }
    }

    //Vertical Line 1
    if(rect1Clicked == true && rect4Clicked == true && rect7Clicked == true) {
      if(rect1Owner == "Player 1" && rect4Owner == "Player 1" && rect7Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect1Owner == "Player 2" && rect4Owner == "Player 2" && rect7Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p1Wins + " wins");
          setWin = true;
        }
      }
    }

    //Vertical Line 2
    if(rect2Clicked == true && rect5Clicked == true && rect8Clicked == true) {
      if(rect2Owner == "Player 1" && rect5Owner == "Player 1" && rect8Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);


        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect2Owner == "Player 2" && rect5Owner == "Player 2" && rect8Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p1Wins + " wins");
          setWin = true;
        }
      }
    }

    //Vertical Line 3
    if(rect3Clicked == true && rect6Clicked == true && rect9Clicked == true) {
      if(rect3Owner == "Player 1" && rect6Owner == "Player 1" && rect9Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");

          if(setWin == false) {
            p2Wins = p2Wins + 1;
            console.log("Player 2 has now " + p1Wins + " wins");
            setWin = true;
          }
        }

      }else if(rect3Owner == "Player 2" && rect6Owner == "Player 2" && rect9Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p1Wins + " wins");
          setWin = true;
        }
      }
    }

    //Left Top to Right Bottom
    if(rect1Clicked == true && rect5Clicked == true && rect9Clicked == true) {
      if(rect1Owner == "Player 1" && rect5Owner == "Player 1" && rect9Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect1Owner == "Player 2" && rect5Owner == "Player 2" && rect9Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p1Wins + " wins");
          setWin = true;
        }
      }
    }

    //Right Top to Left Bottom
    if(rect3Clicked == true && rect5Clicked == true && rect7Clicked == true) {
      if(rect3Owner == "Player 1" && rect5Owner == "Player 1" && rect7Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect3Owner == "Player 2" && rect5Owner == "Player 2" && rect7Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p1Wins + " wins");
          setWin = true;
        }
      }
    }
  }
  else if(gameGrid == "4x4") {
    //Draw
    if(rect1Clicked == true && rect2Clicked == true && rect3Clicked == true && rect4Clicked == true && rect5Clicked == true && rect6Clicked == true &&
      rect7Clicked == true && rect8Clicked == true && rect9Clicked == true && rect10Clicked == true && rect11Clicked == true && rect12Clicked == true &&
      rect13Clicked == true && rect14Clicked == true && rect15Clicked == true && rect16Clicked == true) {
      fill(backgroundColour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Draw/No Winner!", (width-600)/4, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
    }

    //Horizontal Line 1
    if(rect1Clicked == true && rect2Clicked == true && rect3Clicked == true && rect4Clicked == true) {
      if(rect1Owner == "Player 1" && rect2Owner == "Player 1" && rect3Owner == "Player 1" && rect4Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect1Owner == "Player 2" && rect2Owner == "Player 2" && rect3Owner == "Player 2" && rect4Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Horizontal Line 2
    if(rect5Clicked == true && rect6Clicked == true && rect7Clicked == true && rect8Clicked == true) {
      if(rect5Owner == "Player 1" && rect6Owner == "Player 1" && rect7Owner == "Player 1" && rect8Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect5Owner == "Player 2" && rect6Owner == "Player 2" && rect7Owner == "Player 2" && rect8Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Horizontal Line 3
    if(rect9Clicked == true && rect10Clicked == true && rect11Clicked == true && rect12Clicked == true) {
      if(rect9Owner == "Player 1" && rect10Owner == "Player 1" && rect11Owner == "Player 1" && rect12Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect9Owner == "Player 2" && rect10Owner == "Player 2" && rect11Owner == "Player 2" && rect12Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Horizontal Line 4
    if(rect13Clicked == true && rect14Clicked == true && rect15Clicked == true && rect16Clicked == true) {
      if(rect13Owner == "Player 1" && rect14Owner == "Player 1" && rect15Owner == "Player 1" && rect16Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect13Owner == "Player 2" && rect14Owner == "Player 2" && rect15Owner == "Player 2" && rect16Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Vertical Line 1
    if(rect1Clicked == true && rect5Clicked == true && rect9Clicked == true && rect13Clicked == true) {
      if(rect1Owner == "Player 1" && rect5Owner == "Player 1" && rect9Owner == "Player 1" && rect13Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect1Owner == "Player 2" && rect5Owner == "Player 2" && rect9Owner == "Player 2" && rect13Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Vertical Line 2
    if(rect2Clicked == true && rect6Clicked == true && rect10Clicked == true && rect14Clicked == true) {
      if(rect2Owner == "Player 1" && rect6Owner == "Player 1" && rect10Owner == "Player 1" && rect14Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect2Owner == "Player 2" && rect6Owner == "Player 2" && rect10Owner == "Player 2" && rect14Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Vertical Line 3
    if(rect3Clicked == true && rect7Clicked == true && rect11Clicked == true && rect15Clicked == true) {
      if(rect3Owner == "Player 1" && rect7Owner == "Player 1" && rect11Owner == "Player 1" && rect15Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect3Owner == "Player 2" && rect7Owner == "Player 2" && rect11Owner == "Player 2" && rect15Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Vertical Line 4
    if(rect4Clicked == true && rect8Clicked == true && rect12Clicked == true && rect16Clicked == true) {
      if(rect4Owner == "Player 1" && rect8Owner == "Player 1" && rect12Owner == "Player 1" && rect16Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect4Owner == "Player 2" && rect8Owner == "Player 2" && rect12Owner == "Player 2" && rect16Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Top Left to Bottom Right
    if(rect1Clicked == true && rect6Clicked == true && rect11Clicked == true && rect16Clicked == true) {
      if(rect1Owner == "Player 1" && rect6Owner == "Player 1" && rect11Owner == "Player 1" && rect16Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect1Owner == "Player 2" && rect6Owner == "Player 2" && rect11Owner == "Player 2" && rect16Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }

    //Top Right to Bottom Left
    if(rect4Clicked == true && rect7Clicked == true && rect10Clicked == true && rect13Clicked == true) {
      if(rect4Owner == "Player 1" && rect7Owner == "Player 1" && rect10Owner == "Player 1" && rect13Owner == "Player 1") {
        fill(p1Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 1 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 1 has now " + p1Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 1";

        if(setWin == false) {
          p1Wins = p1Wins + 1;
          console.log("Player 1 has now " + p1Wins + " wins");
          setWin = true;
        }

      }else if(rect4Owner == "Player 2" && rect7Owner == "Player 2" && rect10Owner == "Player 2" && rect13Owner == "Player 2") {
        fill(p2Colour);
        rect(0, 0, endScreenWidth, endScreenHeigth);
        inProgress = false;

        fill(textColour);
        strokeWeight(0);
        textSize(50);
        text("Player 2 has won the game!", (width-600)/8, height/3);
        textSize(25);
        text(GameVersion, 10, 30);
        textSize(20);
        text("To Play the game again, click somewhere on the screen!", (width-600)/5 - 20, height/3 + 60);
        textSize(30);
        text("Player 2 has now " + p2Wins + " wins!", (width-600)/4 + 15, height/2 + 100);

        lastWin = "Player 2";

        if(setWin == false) {
          p2Wins = p2Wins + 1;
          console.log("Player 2 has now " + p2Wins + " wins");
          setWin = true;
        }
      }
    }
  }
}
 

function mousePressed() {
  if (gameGrid == "3x3") {
    //Rect 1
    if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect1Clicked == false) {

      if(currentPlayer == "Player 1") {
            rect1Owner = "Player 1";
            currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
            rect1Owner = "Player 2";
            currentPlayer = "Player 1";
        }

        rect1Clicked = true;
      }

      //Rect 2
      if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect2Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect2Owner = "Player 1";
          currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
          rect2Owner = "Player 2";
          currentPlayer = "Player 1";
      }

        rect2Clicked = true;
      }

      //Rect 3
      if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect3Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect3Owner = "Player 1";
          currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
          rect3Owner = "Player 2";
          currentPlayer = "Player 1";
      }

        rect3Clicked = true;
      }

      //Rect 4
      if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect4Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect4Owner = "Player 1";
          currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
          rect4Owner = "Player 2";
          currentPlayer = "Player 1";
      }

        rect4Clicked = true;
      }

      //Rect 5
      if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect5Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect5Owner = "Player 1";
          currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
          rect5Owner = "Player 2";
          currentPlayer = "Player 1";
      }

        rect5Clicked = true;
      }

      //Rect 6
      if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect6Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect6Owner = "Player 1";
          currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
          rect6Owner = "Player 2";
          currentPlayer = "Player 1";
      }

        rect6Clicked = true;
      }

      //Rect 7
      if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect7Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect7Owner = "Player 1";
          currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
          rect7Owner = "Player 2";
          currentPlayer = "Player 1";
      }

        rect7Clicked = true;
      }

      //Rect 8
      if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect8Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect8Owner = "Player 1";
          currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
          rect8Owner = "Player 2";
          currentPlayer = "Player 1";
      }

        rect8Clicked = true;
      }

      //Rect 9
      if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect9Clicked == false) {
    
        if(currentPlayer == "Player 1") {
          rect9Owner = "Player 1";
          currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
          rect9Owner = "Player 2";
          currentPlayer = "Player 1";
      }

      rect9Clicked = true;
    }
  }
  else if (gameGrid == "4x4") {
    //Rect 1
    if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect1Clicked == false) {

      if(currentPlayer == "Player 1") {
        rect1Owner = "Player 1";
        currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
        rect1Owner = "Player 2";
        currentPlayer = "Player 1";
      }

        rect1Clicked = true;
      }

      //Rect 2
      if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect2Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect2Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect2Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect2Clicked = true;
      }

      //Rect 3
      if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect3Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect3Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect3Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect3Clicked = true;
      }

      //Rect 4
      if(mouseX > xPos + 3*rectWidth && mouseX < xPos + 4*rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect4Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect4Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect4Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect4Clicked = true;
      }

      //Rect 5
      if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect5Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect5Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect5Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect5Clicked = true;
      }

      //Rect 6
      if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect6Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect6Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect6Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect6Clicked = true;
      }

      //Rect 7
      if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect7Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect7Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect7Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect7Clicked = true;
      }

      //Rect 8
      if(mouseX > xPos + 3*rectWidth && mouseX < xPos + 4*rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect8Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect8Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect8Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect8Clicked = true;
      }

      //Rect 9
      if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect9Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect9Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect9Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect9Clicked = true;
      }

      //Rect 10
      if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect10Clicked == false) {

        if(currentPlayer == "Player 1") {
          rect10Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect10Owner = "Player 2";
          currentPlayer = "Player 1";
        }

        rect10Clicked = true;
      }

      //Rect 11
      if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect11Clicked == false) {
    
        if(currentPlayer == "Player 1") {
          rect11Owner = "Player 1";
          currentPlayer = "Player 2";
        }else if(currentPlayer == "Player 2") {
          rect11Owner = "Player 2";
          currentPlayer = "Player 1";
        }

      rect11Clicked = true;
    }

    //Rect 12
    if(mouseX > xPos + 3*rectWidth && mouseX < xPos + 4*rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect12Clicked == false) {
    
      if(currentPlayer == "Player 1") {
        rect12Owner = "Player 1";
        currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
        rect12Owner = "Player 2";
        currentPlayer = "Player 1";
      }

    rect12Clicked = true;
    }

    //Rect 13
    if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos + 3*rectHeigth && mouseY < yPos + 4*rectHeigth && rect13Clicked == false) {

      if(currentPlayer == "Player 1") {
        rect13Owner = "Player 1";
        currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
        rect13Owner = "Player 2";
        currentPlayer = "Player 1";
      }

      rect13Clicked = true;
    }

    //Rect 14
    if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos + 3*rectHeigth && mouseY < yPos + 4*rectHeigth && rect14Clicked == false) {

      if(currentPlayer == "Player 1") {
        rect14Owner = "Player 1";
        currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
        rect14Owner = "Player 2";
        currentPlayer = "Player 1";
      }

      rect14Clicked = true;
    }

    //Rect 15
    if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos + 3*rectHeigth && mouseY < yPos + 4*rectHeigth && rect15Clicked == false) {
  
      if(currentPlayer == "Player 1") {
        rect15Owner = "Player 1";
        currentPlayer = "Player 2";
      }else if(currentPlayer == "Player 2") {
        rect15Owner = "Player 2";
        currentPlayer = "Player 1";
      }

    rect15Clicked = true;
  }

  //Rect 16
  if(mouseX > xPos + 3*rectWidth && mouseX < xPos + 4*rectWidth && mouseY > yPos + 3*rectHeigth && mouseY < yPos + 4*rectHeigth && rect16Clicked == false) {
  
    if(currentPlayer == "Player 1") {
      rect16Owner = "Player 1";
      currentPlayer = "Player 2";
    }else if(currentPlayer == "Player 2") {
      rect16Owner = "Player 2";
      currentPlayer = "Player 1";
    }

  rect16Clicked = true;
  }
}


  //Change Grid
  if(mouseX > buttonxPos && mouseX < buttonxPos + buttonWidth && mouseY > buttonyPos && mouseY < buttonyPos + buttonHeight && gameGrid == "4x4") {
    gameGrid = "3x3";
    rectWidth = 250;
    rectHeigth = 250;
    rectBorderRadius = 25;
    p1Wins = 0;
    p2Wins = 0;
    inProgress = false;

    rect1Owner = " ";
    rect2Owner = " ";
    rect3Owner = " ";
    rect4Owner = " ";
    rect5Owner = " ";
    rect6Owner = " ";
    rect7Owner = " ";
    rect8Owner = " ";
    rect9Owner = " ";
    rect10Owner = " ";
    rect11Owner = " ";
    rect12Owner = " ";
    rect13Owner = " ";
    rect14Owner = " ";
    rect15Owner = " ";
    rect16Owner = " ";

    currentPlayer = random(['Player 1', 'Player 2']);
    console.log(currentPlayer);
  }
  
  if(mouseX > buttonxPos + buttonWidth && mouseX < buttonxPos + 2*buttonWidth && mouseY > buttonyPos && mouseY < buttonyPos + buttonHeight && gameGrid == "3x3") {
    gameGrid = "4x4";
    rectWidth = 187.5;
    rectHeigth = 187.5;
    rectBorderRadius = 20;
    p1Wins = 0;
    p2Wins = 0;
    inProgress = false;

    rect1Owner = " ";
    rect2Owner = " ";
    rect3Owner = " ";
    rect4Owner = " ";
    rect5Owner = " ";
    rect6Owner = " ";
    rect7Owner = " ";
    rect8Owner = " ";
    rect9Owner = " ";

    currentPlayer = random(['Player 1', 'Player 2']);
    console.log(currentPlayer);
  }

  //Change Theme
  if(mouseX > buttonxPos && mouseX < buttonxPos + buttonWidth && mouseY > buttonyPos + buttonHeight + 65 && mouseY < buttonyPos + 65 + (2*buttonHeight) &&
  theme == "light") {
    theme = "default";
  }

  if(mouseX > buttonxPos + buttonWidth && mouseX < buttonxPos + 2*buttonWidth && mouseY > buttonyPos + buttonHeight + 65 && mouseY < buttonyPos + 65 + (2*buttonHeight) &&
  theme == "default") {
    theme = "light";
  }

  //Game Reset
  if(inProgress == false) {
    
    rect1Clicked = false;
    rect2Clicked = false;
    rect3Clicked = false;
    rect4Clicked = false;
    rect5Clicked = false;
    rect6Clicked = false;
    rect7Clicked = false;
    rect8Clicked = false;
    rect9Clicked = false;
    rect10Clicked = false;
    rect11Clicked = false;
    rect12Clicked = false;
    rect13Clicked = false;
    rect14Clicked = false;
    rect15Clicked = false;
    rect16Clicked = false;


    rect1Owner = " ";
    rect2Owner = " ";
    rect3Owner = " ";
    rect4Owner = " ";
    rect5Owner = " ";
    rect6Owner = " ";
    rect7Owner = " ";
    rect8Owner = " ";
    rect9Owner = " ";
    rect10Owner = " ";
    rect11Owner = " ";
    rect12Owner = " ";
    rect13Owner = " ";
    rect14Owner = " ";
    rect15Owner = " ";
    rect16Owner = " ";

    inProgress = true;

    currentPlayer = random(['Player 1', 'Player 2']);
    console.log(currentPlayer);

    if(setWin == true) {
      setWin = false;
    }
  }
}