//Variables

let textColour = "#FFFFFF";
let darkModeColour = "#121212";
let copyright = "© rileydeman™";

///Rect Information
let xPos = 50; //Start x Position
let yPos = 50; //Start y Position
let rectWidth = 250; //Width of Grid Rectangles
let rectHeigth = 250; //Height of Grid Rectangles
let rectBorderRadius = 25; //Border radius of Grid Rectangles

let rect1Clicked = false;
let rect2Clicked = false;
let rect3Clicked = false;
let rect4Clicked = false;
let rect5Clicked = false;
let rect6Clicked = false;
let rect7Clicked = false;
let rect8Clicked = false;
let rect9Clicked = false;

let rect1Colour = "#FFFFFF";
let rect2Colour = "#FFFFFF";
let rect3Colour = "#FFFFFF";
let rect4Colour = "#FFFFFF";
let rect5Colour = "#FFFFFF";
let rect6Colour = "#FFFFFF";
let rect7Colour = "#FFFFFF";
let rect8Colour = "#FFFFFF";
let rect9Colour = "#FFFFFF";

///Player Information
let currentPlayer = "Player 1";
let p1Colour = "#8000FF";
let p2Colour = "#FF0000";

//Game Information
let inProgress = true;
let GameVersion = "V1.5";

//Endscreen Information
let endScreenHeigth = 900;
let endScreenWidth = 900;

function setup() {
  createCanvas(900, 900);
  frameRate(165);

  currentPlayer = random(['Player 1', 'Player 2']);
}

function draw() {
  background("#121212"); //Background Colour Dark Mode

  //Current Player text
  if (currentPlayer == "Player 1") {
    fill(p1Colour);
  }else if (currentPlayer == "Player 2") {
    fill(p2Colour);
  }
  rect(xPos, yPos + 3*rectWidth + 10, 40, 40);

  textFont("Helvitica");
  fill(textColour)
  textSize(15);
  text(copyright, xPos + 2*rectWidth + 140, yPos + 3*rectWidth + 43)

  textFont("Trade Winds");
  textSize(25);
  text(currentPlayer, xPos + 45, yPos + 3*rectWidth + 40);
  text(GameVersion, 10, 30);

  //Rect theme
  stroke("#121212") //Stroke Colour Dark Mode
  strokeWeight(12); //Stroke Width
  
  //Top LineA
  fill(rect1Colour);
  rect(xPos, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 1

  fill(rect2Colour);
  rect(xPos + rectWidth, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 2

  fill(rect3Colour);
  rect(xPos + 2*rectWidth, yPos, rectWidth, rectHeigth, rectBorderRadius); //Rect 3
  
  //Second Line
  fill(rect4Colour);
  rect(xPos, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 4

  fill(rect5Colour);
  rect(xPos + rectWidth, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 5

  fill(rect6Colour);
  rect(xPos + 2*rectWidth, yPos + rectHeigth, rectWidth, rectHeigth, rectBorderRadius); //Rect 6
  
  //Third Line
  fill(rect7Colour);
  rect(xPos, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 7

  fill(rect8Colour);
  rect(xPos + rectWidth, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 8

  fill(rect9Colour);
  rect(xPos + 2*rectWidth, yPos + 2*rectHeigth, rectHeigth, rectWidth, rectBorderRadius); //Rect 9

  //3 in a row checks

  //Draw
  if(rect1Clicked == true && rect2Clicked == true && rect3Clicked == true && rect4Clicked == true && rect5Clicked == true &&
    rect6Clicked == true && rect7Clicked == true && rect8Clicked == true && rect9Clicked == true) {
    fill(darkModeColour);
    rect(0, 0, endScreenWidth, endScreenHeigth);
    inProgress = false;

    fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Draw/No Winner!", width/4, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
  }

  //Horizontal Line 1
  if(rect1Clicked == true && rect2Clicked == true && rect3Clicked == true) {
    if(rect1Colour == p1Colour && rect2Colour == p1Colour && rect3Colour == p1Colour) {
      fill(p1Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 1 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
      
    }else if(rect1Colour == p2Colour && rect2Colour == p2Colour && rect3Colour == p2Colour) {
      fill(p2Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;
      
      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 2 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }
  }

  //Horizontal Line 2
  if(rect4Clicked == true && rect5Clicked == true && rect6Clicked == true) {
    if(rect4Colour == p1Colour && rect5Colour == p1Colour && rect6Colour == p1Colour) {
      fill(p1Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 1 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }else if(rect4Colour == p2Colour && rect5Colour == p2Colour && rect6Colour == p2Colour) {
      fill(p2Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 2 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }
  }

  //Horizontal Line 3
  if(rect7Clicked == true && rect8Clicked == true && rect9Clicked == true) {
    if(rect7Colour == p1Colour && rect8Colour == p1Colour && rect9Colour == p1Colour) {
      fill(p1Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 1 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }else if(rect7Colour == p2Colour && rect8Colour == p2Colour && rect9Colour == p2Colour) {
      fill(p2Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 2 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }
  }

  //Vertical Line 1
  if(rect1Clicked == true && rect4Clicked == true && rect7Clicked == true) {
    if(rect1Colour == p1Colour && rect4Colour == p1Colour && rect7Colour == p1Colour) {
      fill(p1Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 1 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }else if(rect1Colour == p2Colour && rect4Colour == p2Colour && rect7Colour == p2Colour) {
      fill(p2Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 2 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }
  }

  //Vertical Line 2
  if(rect2Clicked == true && rect5Clicked == true && rect8Clicked == true) {
    if(rect2Colour == p1Colour && rect5Colour == p1Colour && rect8Colour == p1Colour) {
      fill(p1Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 1 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }else if(rect2Colour == p2Colour && rect5Colour == p2Colour && rect8Colour == p2Colour) {
      fill(p2Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 2 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }
  }

  //Vertical Line 3
  if(rect3Clicked == true && rect6Clicked == true && rect9Clicked == true) {
    if(rect3Colour == p1Colour && rect6Colour == p1Colour && rect9Colour == p1Colour) {
      fill(p1Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 1 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }else if(rect3Colour == p2Colour && rect6Colour == p2Colour && rect9Colour == p2Colour) {
      fill(p2Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 2 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }
  }

  //Left Top to Right Bottom
  if(rect1Clicked == true && rect5Clicked == true && rect9Clicked == true) {
    if(rect1Colour == p1Colour && rect5Colour == p1Colour && rect9Colour == p1Colour) {
      fill(p1Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 1 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }else if(rect1Colour == p2Colour && rect5Colour == p2Colour && rect9Colour == p2Colour) {
      fill(p2Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 2 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }
  }

  //Right Top to Left Bottom
  if(rect3Clicked == true && rect5Clicked == true && rect7Clicked == true) {
    if(rect3Colour == p1Colour && rect5Colour == p1Colour && rect7Colour == p1Colour) {
      fill(p1Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 1 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }else if(rect3Colour == p2Colour && rect5Colour == p2Colour && rect7Colour == p2Colour) {
      fill(p2Colour);
      rect(0, 0, endScreenWidth, endScreenHeigth);
      inProgress = false;

      fill(textColour);
      strokeWeight(0);
      textSize(50);
      text("Player 2 has won the game!", width/8, height/3);
      textSize(25);
      text(GameVersion, 10, 30);
      textSize(20);
      text("To Play the game again, click somewhere on the screen!", width/5 - 20, height/3 + 60);
    }
  }
}
 

function mousePressed() {
  //Rect 1
  if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect1Clicked == false) {

    if(currentPlayer == "Player 1") {
        rect1Colour = p1Colour;
        currentPlayer = "Player 2";
    }else if(currentPlayer == "Player 2") {
        rect1Colour = p2Colour;
        currentPlayer = "Player 1";
    }

    rect1Clicked = true;
  }

  //Rect 2
  if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect2Clicked == false) {

    if(currentPlayer == "Player 1") {
      rect2Colour = p1Colour;
      currentPlayer = "Player 2";
  }else if(currentPlayer == "Player 2") {
      rect2Colour = p2Colour;
      currentPlayer = "Player 1";
  }

    rect2Clicked = true;
  }

  //Rect 3
  if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos && mouseY < yPos + rectHeigth && rect3Clicked == false) {

    if(currentPlayer == "Player 1") {
      rect3Colour = p1Colour;
      currentPlayer = "Player 2";
  }else if(currentPlayer == "Player 2") {
      rect3Colour = p2Colour;
      currentPlayer = "Player 1";
  }

    rect3Clicked = true;
  }

  //Rect 4
  if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect4Clicked == false) {

    if(currentPlayer == "Player 1") {
      rect4Colour = p1Colour;
      currentPlayer = "Player 2";
  }else if(currentPlayer == "Player 2") {
      rect4Colour = p2Colour;
      currentPlayer = "Player 1";
  }

    rect4Clicked = true;
  }

  //Rect 5
  if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect5Clicked == false) {

    if(currentPlayer == "Player 1") {
      rect5Colour = p1Colour;
      currentPlayer = "Player 2";
  }else if(currentPlayer == "Player 2") {
      rect5Colour = p2Colour;
      currentPlayer = "Player 1";
  }

    rect5Clicked = true;
  }

  //Rect 6
  if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos + rectHeigth && mouseY < yPos + 2*rectHeigth && rect6Clicked == false) {

    if(currentPlayer == "Player 1") {
      rect6Colour = p1Colour;
      currentPlayer = "Player 2";
  }else if(currentPlayer == "Player 2") {
      rect6Colour = p2Colour;
      currentPlayer = "Player 1";
  }

    rect6Clicked = true;
  }

  //Rect 7
  if(mouseX > xPos && mouseX < xPos + rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect7Clicked == false) {

    if(currentPlayer == "Player 1") {
      rect7Colour = p1Colour;
      currentPlayer = "Player 2";
  }else if(currentPlayer == "Player 2") {
      rect7Colour = p2Colour;
      currentPlayer = "Player 1";
  }

    rect7Clicked = true;
  }

  //Rect 8
  if(mouseX > xPos + rectWidth && mouseX < xPos + 2*rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect8Clicked == false) {

    if(currentPlayer == "Player 1") {
      rect8Colour = p1Colour;
      currentPlayer = "Player 2";
  }else if(currentPlayer == "Player 2") {
      rect8Colour = p2Colour;
      currentPlayer = "Player 1";
  }

    rect8Clicked = true;
  }

  //Rect 9
  if(mouseX > xPos + 2*rectWidth && mouseX < xPos + 3*rectWidth && mouseY > yPos + 2*rectHeigth && mouseY < yPos + 3*rectHeigth && rect9Clicked == false) {

    if(currentPlayer == "Player 1") {
      rect9Colour = p1Colour;
      currentPlayer = "Player 2";
  }else if(currentPlayer == "Player 2") {
      rect9Colour = p2Colour;
      currentPlayer = "Player 1";
  }

    rect9Clicked = true;
  }

  if(inProgress == false) {
    
    rect1Clicked = false;
    rect2Clicked = false;
    rect3Clicked = false;
    rect4Clicked = false;
    rect5Clicked = false;
    rect6Clicked = false;
    rect7Clicked = false;
    rect8Clicked = false;
    rect9Clicked = false;

    rect1Colour = "#FFFFFF";
    rect2Colour = "#FFFFFF";
    rect3Colour = "#FFFFFF";
    rect4Colour = "#FFFFFF";
    rect5Colour = "#FFFFFF";
    rect6Colour = "#FFFFFF";
    rect7Colour = "#FFFFFF";
    rect8Colour = "#FFFFFF";
    rect9Colour = "#FFFFFF";

    inProgress = true;

    currentPlayer = random(['Player 1', 'Player 2']);
    console.log(currentPlayer);
  }
}